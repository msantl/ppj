char x = 'abc';
