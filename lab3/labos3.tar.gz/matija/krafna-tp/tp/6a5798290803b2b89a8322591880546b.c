int main(void) {
  int printf(const char nesto[]);
  return printf("hello world!\n");
}

int nesto(void) {
  printf("bok");
}

int printf(const char format[]) {
  return 0;
}
