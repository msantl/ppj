int main(void){
char a[4]="\\\\";
return 0;
}