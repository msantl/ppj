int main(void){
  int a[12]={1,2,3};
  a[0]=1;

  return 0;
}