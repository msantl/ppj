int main (void) {
  int a = 0;
  a = a+1jfngf;
  return 0;
}