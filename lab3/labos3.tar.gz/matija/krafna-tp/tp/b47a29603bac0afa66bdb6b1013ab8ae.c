int main(void) {
  char d[10]={'a','b','c'};
  char dd[10]={'d','e','f'};
  d=dd;
  return 0;
}
