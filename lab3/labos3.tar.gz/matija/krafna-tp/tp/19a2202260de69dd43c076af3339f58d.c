int f(int a, int b){
  return a+b;
  }
int main(void) {
 int x;
 x=f(6);
 return 0;
 }
