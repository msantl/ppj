int f(int a, int b, int c){
      return char(7);
}

int main(void){
int pov;
return pov=f(1,2,3);
}