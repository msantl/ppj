

int main(void) {
  int a(int b);
  return 5;
}

int a(int c) {
  return 0;
}

int a(int f);