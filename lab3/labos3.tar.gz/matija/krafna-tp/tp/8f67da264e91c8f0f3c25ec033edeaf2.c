int a[2]={2};
char b[7]="x\"\0\n\t\";
int main(int a)
{
return a;
}