int x;
int y;
int main(void) {
  int z;
  int bla;
  int y, hg;
return 0;
}