int main(void) {
  
  int a[2];
  a[0]=3;
  a[0] += 2;               
  
  return 0;
}
