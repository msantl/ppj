
void f( int c ) {
  int a, o;
  f();
}

int main(void) {
  return 0;
}
