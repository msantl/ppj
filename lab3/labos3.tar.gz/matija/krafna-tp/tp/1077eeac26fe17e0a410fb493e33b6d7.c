int main(void)
{
  int i=0;
  for (i=2; i<i++; i++);
  {
  do {i++;} while(i==0);
  }
return 0;
}