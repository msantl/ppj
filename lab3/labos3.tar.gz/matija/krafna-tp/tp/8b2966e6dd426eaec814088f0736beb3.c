int main(void) {
  
  const int x=1;
  int y;
  
  const char a='a';
  char b;
  y=x;
  
  y=a;
  
  
    
  return 0;
  }

