void p(void); //deklaracija funkcija

int main(void){
    int p(int a); //nova neispravna deklaracija funkcije
    return 0;
}

void p(void){
   return;
}