int a(int a){
  return 2;
}