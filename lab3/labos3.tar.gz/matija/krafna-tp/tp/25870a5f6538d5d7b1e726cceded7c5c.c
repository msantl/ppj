int main(void) {
 int a[10];
 a[1]
 =8;
 return 0;
}


