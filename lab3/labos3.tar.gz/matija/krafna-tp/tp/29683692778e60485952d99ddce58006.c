int main(void) {
 int a[3];
 a[2]
  [2];
 return 0;
}