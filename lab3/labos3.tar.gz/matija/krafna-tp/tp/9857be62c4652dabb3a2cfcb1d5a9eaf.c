int main(void)
{
  int a=3;
  int b=2;
  int c=1;
  int d=5;
  int e;
  e=a*b+c*d;
  return d;
}