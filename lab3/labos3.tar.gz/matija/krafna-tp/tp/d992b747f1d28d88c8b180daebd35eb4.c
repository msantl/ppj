int main(void) {
int a = 666;
const char e='e';
int s=3;
{
int a = 5;
int y = a + 1; // 6
const int v=666;

s = y + 1; // 7
}
s = a + 1; // 4
return 0;
}