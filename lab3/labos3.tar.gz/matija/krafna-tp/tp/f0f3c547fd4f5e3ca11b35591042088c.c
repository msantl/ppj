int main(void)
{  
int a=2;
 if (a) then
 return 0;
 }
