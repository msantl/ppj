int a = 100;
char b[1025];

int main(void) {
  return 0;
}