
int main(void)
{
    int a = 5;
    return;
}
