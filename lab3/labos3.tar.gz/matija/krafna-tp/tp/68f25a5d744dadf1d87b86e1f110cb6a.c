int main(void) {
  int a;
  int b;
  int c;
  a=4;
  b=6;
  c=a+b;
  return c;
}