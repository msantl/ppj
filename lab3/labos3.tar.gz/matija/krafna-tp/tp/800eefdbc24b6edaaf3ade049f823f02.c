
int f(void);
int main(void) {
  int x = 3;
  int y = x;
  return y;
}
int f(void){
  return 2;
}