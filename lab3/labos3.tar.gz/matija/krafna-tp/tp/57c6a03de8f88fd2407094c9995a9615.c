int f( int b) {

int main=6+b;
return 0;
}