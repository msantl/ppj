int main(void) {
  char a[10] = {'a','b','c'};
  return 0;
 }