int main(void) {
  int a[ 02001 ];
   
  return 0;
}
