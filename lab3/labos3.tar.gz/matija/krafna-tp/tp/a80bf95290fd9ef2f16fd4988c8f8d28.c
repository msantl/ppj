 int main(void) {
 int x = 5;
 int x = 6; // greska
 return 0;
 }
