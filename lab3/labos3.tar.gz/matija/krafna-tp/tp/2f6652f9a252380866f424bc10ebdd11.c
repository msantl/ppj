int main(void){

int z;

return ;
}