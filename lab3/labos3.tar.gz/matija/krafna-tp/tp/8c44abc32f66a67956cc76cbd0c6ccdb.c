int main(void){
char c[1000]=1;
return 0;
}