int a[2]={2};
char b[2]="xs";
int main(int a)
{
return a;
}