
int main(void) {
   
   int g(int a);
   
   return 1;
}

int g(void) {
   return 4;
}