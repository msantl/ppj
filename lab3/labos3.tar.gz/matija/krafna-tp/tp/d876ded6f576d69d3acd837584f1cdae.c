int f(void);
int main(void) {
  return 0;
￼￼￼￼￼}
int f(void) { return 0;
}

￼￼￼￼￼