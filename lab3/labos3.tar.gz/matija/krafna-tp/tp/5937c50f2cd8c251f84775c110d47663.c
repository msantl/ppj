int x;
char f(int x)
{
  char xy;
  return x;
}
int main(int a)
{ 
  b[0]=(char)('\0'+b[-1]);
  return a;
}