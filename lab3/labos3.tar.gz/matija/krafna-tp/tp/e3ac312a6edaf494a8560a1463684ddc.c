
int main(void) {
  
  const int x=1;
  int y;
  
  const char a='a';
  char b;

  x=b;
    
  return 0;
}


