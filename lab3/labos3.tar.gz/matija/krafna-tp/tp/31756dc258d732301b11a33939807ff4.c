int main(void) {
  
  char a = 'aaaaaaaaaaaaa';               
  
  return 0;
}
