int main(void) {
    int x = (int)'a'
        + (char)"abc";
    return 0;
}
