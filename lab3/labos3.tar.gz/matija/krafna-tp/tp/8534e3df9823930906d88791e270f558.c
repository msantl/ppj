char bar(void) {
  if (0) {
    return 97; // greska
  } else {
    return (char)97;
  }
}
