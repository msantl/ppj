void f(void);
int main(void) {
f();
return 0;
}

void f(void) {
  int a;
  a = a == 5 * 4 <= 3 > 2 + 1 * (char) 4;
  return;
}
