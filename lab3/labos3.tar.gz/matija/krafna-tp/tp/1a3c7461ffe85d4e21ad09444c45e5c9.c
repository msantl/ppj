char printf(const char format[]) {
  return 0;
}
int main(void) {
  return printf("hello world!\n");
}
