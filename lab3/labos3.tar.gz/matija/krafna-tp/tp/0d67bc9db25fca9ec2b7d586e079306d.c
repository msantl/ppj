char a = 'a';
char b = 'n';
char c = a+b+a;
