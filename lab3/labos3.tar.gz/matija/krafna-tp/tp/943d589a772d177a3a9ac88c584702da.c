int main(void)
{
  int i=0; 
  if (i<0 && i>0) 
  i--;
  else if (i++)
  {
  return 90;
  }
  else
  {
  j++;
  }
return 0;
}