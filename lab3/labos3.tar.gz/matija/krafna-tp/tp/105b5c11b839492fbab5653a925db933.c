int a = 100;
char b = 250;
int main(void) {
  return 0;
}