char x = '1';

char main(void) {return x;}