int main(void) {
  int a(int b);
  char k[10]="\n";
  return 0;
}

int a(int c) {
  return 0;
}

int a(int f);



