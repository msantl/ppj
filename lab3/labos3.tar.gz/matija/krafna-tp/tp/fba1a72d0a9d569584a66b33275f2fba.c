int main(void) {
  
  int a = 2147483648;               
  
  return 0;
}
