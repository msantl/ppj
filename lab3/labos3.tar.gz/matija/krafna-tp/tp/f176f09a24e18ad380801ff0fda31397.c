int main(void) {
  
  char a = 'aa';               
  
  return 0;
}
