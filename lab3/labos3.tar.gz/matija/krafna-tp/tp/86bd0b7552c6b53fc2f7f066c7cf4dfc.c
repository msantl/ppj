int main(void)
{
  int i=0; 
  while (i--==0)
  {
  j++;
  }
return 0;
}