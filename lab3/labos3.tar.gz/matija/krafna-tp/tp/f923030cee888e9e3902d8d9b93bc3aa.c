int main(void){
  int x=3;
  int y = x+1;
  int a[1000];

  int b = a[1500];
  return 0;
  }