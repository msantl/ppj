int main(void){
  int a[12]={1,2,3};
  int b=2;
  a[0]=b;

  return 0;
}