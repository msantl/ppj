int main(void) {
    return f();
}
