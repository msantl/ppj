int p(void){
  int a[20]="alo";
  return a;
}

int main(void){

return 0;
}

