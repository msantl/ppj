int f(int a, int b){
  return a+b;
  }
int main(void) {
 int x;
 +a=3;
 }
