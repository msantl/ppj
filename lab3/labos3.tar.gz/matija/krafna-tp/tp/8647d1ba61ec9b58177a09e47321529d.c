int x;
int y;
int main(void) {
  int z;
  int bla;
  int y = 1;
return 0;
}