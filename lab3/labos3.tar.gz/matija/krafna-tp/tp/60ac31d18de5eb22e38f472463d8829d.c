
int main(void){
 int y=90;
 char a[1024]="asd";
 char b='d';
 int c[10]={0,2,3};
 char d[10]={'a','b','c'};
 char dd[10]={'d','e','f'};
 d[0]='w'+2;
 c[1]=a[2];
 y=b;
 return 0;
 }
