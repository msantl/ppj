int main(void) {
  char c;
  c = '\a';
  return 0;
}
