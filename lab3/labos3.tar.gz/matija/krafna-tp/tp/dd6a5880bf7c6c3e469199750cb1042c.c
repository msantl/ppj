int main(void) {
  int a;
  a = 'a'
  return 0;
}
