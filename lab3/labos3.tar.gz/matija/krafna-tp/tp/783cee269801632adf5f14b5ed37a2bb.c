int printf(const char format[]) {
  /* i wish i could printf */
  return 0;
}

int main(void) {
  return printf("hello world!\n");
}
