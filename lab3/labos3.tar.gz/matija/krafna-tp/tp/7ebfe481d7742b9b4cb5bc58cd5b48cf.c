const int f(void) {
  int a;
  int a;
  return 0;
}

int main(void) {

return 0;
}
