int x;
char f(char x)
{
  {
  x++;
  }
  return (char)x;
}
int main(int x)
{ 
  char x;
  return a;
}