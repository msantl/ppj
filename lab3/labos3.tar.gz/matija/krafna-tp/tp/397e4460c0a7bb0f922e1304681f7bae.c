
int f( int g ) {
  int a, c;
  
  a++;
  
  a = c++ = 3;
  
}

int main(void) {
  return 0;
}
