int main(void) {
    int x;
    x = 3;
    (x) = x + 1;
    (x+1) = 4;
    return 0;
}
