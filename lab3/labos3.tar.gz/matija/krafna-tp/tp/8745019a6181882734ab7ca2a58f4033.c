
void f( int c ) {
  return ;
}

int main( void ) {
    int a, f;
char c = 'c';
   // a = f(3);
//    f( 2, 5);
    return 0;
}


