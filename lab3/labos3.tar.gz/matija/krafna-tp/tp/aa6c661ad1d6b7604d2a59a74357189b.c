int main(void){

int a[10] = "ab\\c";
char b='5';
return 0;
}
