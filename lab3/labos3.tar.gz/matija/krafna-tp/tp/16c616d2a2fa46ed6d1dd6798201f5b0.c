int b = 0123;

int main(void) {
  return 0;
}
