int x;
int main(void){

char x=0;
while(x==0){
break;
}

return 0;
}