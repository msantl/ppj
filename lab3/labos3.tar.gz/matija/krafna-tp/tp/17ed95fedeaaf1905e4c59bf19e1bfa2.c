int main(void){

int a[1024] = "       f         h\s";
char b='p';
return 0;
}