int main(void){
  
  int a;
  +a=5;
}
  