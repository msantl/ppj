
int main(void)
{
  return 'c'/0;
}