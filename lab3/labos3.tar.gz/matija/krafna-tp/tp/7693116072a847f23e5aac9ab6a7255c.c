
int main(void)
{
int x=0/0;
  return 'c'/0;
}
