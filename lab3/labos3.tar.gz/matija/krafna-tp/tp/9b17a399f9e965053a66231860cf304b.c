
void main( void ) {
    int a;
    void f( int c );
    a = 3;
    return 0;
}

int kla( void ) {
    int f( void );
    return 1;
}

void f( int c ) {
  ;
}


