int y;
int x;

int main(void){
int x;

return;
}