int main(void)
{
  int i=0;
  for (i=2; i<i++; i++);
  {
  do {} while(i==0);
  }
return 0;
}