
int f;

int f(void){
  return 0;
}

int main(void) {
  int x;
  x=f();
  return 0;
}


