int main(void){
  int a;
  a=a+5
  {
  int b;
  b=a+1;
  }
 }