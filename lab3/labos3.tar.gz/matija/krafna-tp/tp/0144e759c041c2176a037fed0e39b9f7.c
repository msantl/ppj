int x;

int main(void) {
  int x;
  int y;
  
  return 0;
}
