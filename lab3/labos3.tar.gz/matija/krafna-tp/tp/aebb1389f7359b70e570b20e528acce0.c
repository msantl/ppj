int main(void) {
  int a(int b);
  char k=''k;
  return 0;
}

int a(int c) {
  return 0;
}

int a(int f);



