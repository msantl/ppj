int a(int a);

int b(int b);

int f(void) {
  int a(int a, int b);
  if (1) {
    int a();
    return 0;
    ;
  }
  return 0;
}

int main(void) {
  return 0;
}
