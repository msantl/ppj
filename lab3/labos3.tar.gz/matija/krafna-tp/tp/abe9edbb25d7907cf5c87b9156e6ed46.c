int  v(int a, int c);

int main(void){

void v(void);
int c=(const char) v('a',3);

return 's';
}

int v(int c, int d){


return 13;
}