int main(void) {
  return f(); // greska
}
int f(void) {
  return 0;
}
