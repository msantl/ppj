int main(void) {
 int a[10] = {2,3,4};
 return 0;
}


