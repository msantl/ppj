int main(void) {
  int main = 3;
  int z;
  if (1)
    int x = 5;
    int y = x + 1; // 6
    z = y + 1; // 7
  }
  z = x + 1; // 4
  return 0;
}
