int x = 3;
int y;
int main(void) {
  int y = x + 1; // 4
return 0;
}