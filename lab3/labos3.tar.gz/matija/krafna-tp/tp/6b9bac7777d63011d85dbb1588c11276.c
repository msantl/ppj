int main(void)
{
  int a=1;
  int b=2;
  int c=3;
  int d;
  d=a+b+c;
  return d;
}