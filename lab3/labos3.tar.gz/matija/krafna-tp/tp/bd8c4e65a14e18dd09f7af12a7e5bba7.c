char x[10] = "bananafkasdfklasl;kfaskl;d;flkas";
