void f(int a, const int b, char c[]) ;

int main(void) {
char a[10];
f(1, 2, a);
return 0;
}

void f(int d, const int b, char c[]){
  int a = b + 1, x[5], t;
  char n[6];
  int e[6] = {1, 2 ,3, 4 , 5, 6};
  a = a == 5 * 4 <= 3 > 2 + 1 * (char) 4;
  return;
}
