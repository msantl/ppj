int main2(void) {
    int x = 5, y;
    int y;
    return 0;
}