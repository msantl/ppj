int f(int x) {
    return x;
}
int main(void) {
    return f();
}
