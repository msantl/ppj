
int f( int g ) {
  int a, c;
  
  a = c++ = a;
  
}

int main(void) {
  return 0;
}
