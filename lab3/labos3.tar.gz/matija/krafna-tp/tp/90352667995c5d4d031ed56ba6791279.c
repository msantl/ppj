

int main(void) {
   void f2(void);
  return 0;
}
