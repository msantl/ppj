void f(int a, int b);

int main(void) {
f(1, 2);
return 0;
}

void f(int a, int b){
  a = a == 5 * 4 <= 3 > 2 + 1 * (char) 4;
  return;
}
