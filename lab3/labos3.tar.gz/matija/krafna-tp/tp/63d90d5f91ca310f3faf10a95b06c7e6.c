
int main(void) {

  return printf("hello world!\n");
}
