int plusTri(void) {
  return 3;
  }
int main(void) {
  int a;
  a=5;
  return a+plusTri();
}

