char  f(void)
{return 'f';}
char main(void)
{  
 int x=0;
 {int x=0;
 x++;
 }
return f();
}
