int main(void)
{
  int i=0; 
  if (i<0 && i>0) 
  i--;
  else if (i++)
  {
  j++;
  }
return 0;
}