int f( int b) {

int maina2=6+b;
return 0;
}